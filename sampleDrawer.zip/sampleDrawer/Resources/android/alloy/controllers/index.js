var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
	var arg = null;
	if (obj) {
		arg = obj[key] || null;
		delete obj[key];
	}
	return arg;
}

function Controller() {

	require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
	this.__controllerPath = 'index';
	this.args = arguments[0] || {};

	if (arguments[0]) {
		var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
		var $model = __processArg(arguments[0], '$model');
		var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
	}
	var $ = this;
	var exports = {};
	var __defers = {};







	$.__views.index = Ti.UI.createWindow(
	{ backgroundColor: "#000000", id: "index" });

	$.__views.index && $.addTopLevelView($.__views.index);
	$.__views.__alloyId0 = Ti.UI.Android.createDrawerLayout(
	{ id: "__alloyId0" });

	$.__views.index.add($.__views.__alloyId0);
	$.__views.__alloyId2 = Ti.UI.createView(
	{ backgroundColor: "red", id: "__alloyId2" });

	$.__views.__alloyId0.leftView = $.__views.__alloyId2;$.__views.__alloyId4 = Ti.UI.createView(
	{ backgroundColor: "white", id: "__alloyId4" });

	$.__views.__alloyId0.centerView = $.__views.__alloyId4;$.__views.__alloyId6 = Ti.UI.createView(
	{ backgroundColor: "blue", id: "__alloyId6" });

	$.__views.__alloyId0.rightView = $.__views.__alloyId6;exports.destroy = function () {};




	_.extend($, $.__views);


	$.index.open();









	_.extend($, exports);
}

module.exports = Controller;