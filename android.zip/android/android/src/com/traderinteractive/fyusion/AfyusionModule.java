/**
 * Android Fyusion Module
 * Copyright TraderInteractive.com
 */
package com.traderinteractive.fyusion;

import org.appcelerator.kroll.KrollModule;
import org.appcelerator.kroll.annotations.Kroll;
import org.appcelerator.titanium.TiApplication;
import org.appcelerator.kroll.common.Log;
import org.appcelerator.kroll.common.TiConfig;
import android.app.Application;

import com.fyusion.sdk.common.FyuseSDK;

@Kroll.module(name="Afyusion", id="com.traderinteractive.fyusion")
public class AfyusionModule extends KrollModule
{
	// Standard Debugging variables
	private static final String LCAT = "AfyusionModule";
	private static final boolean DBG = TiConfig.LOGD;
	private static final String fyusionModuleVersion = "0.0.1";

	public AfyusionModule()
	{
		super();
	}

	@Kroll.onAppCreate
	public static void onAppCreate(TiApplication app)
	{
		// put module init code that needs to run when the application is created
		FyuseSDK.init(app.getInstance().getApplicationContext(), "vgjN_pN5Twoz8EKVe69yOJ", "4oFb5XT3X2gr27NU7On5sILcluG3gZrf");
	}

	// Methods
	@Kroll.method
	public String getVersion()
	{
		return fyusionModuleVersion;
	}

	/*@Kroll.method
	public void setVersionProp(String value) {
		fyusionModuleVersion = value;
	}*/

}
