var activeMovie = null;
var videoMedia = null;

$.videoAdd.addEventListener('click', function(e)
{
  Ti.Media.showCamera({
        mediaTypes:                  [Ti.Media.MEDIA_TYPE_VIDEO],
        videoMaximumDuration:        300000,
        videoQuality:                Titanium.Media.QUALITY_MEDIUM,
        saveToPhotoGallery:          true,
        allowEditing:                false,
        success:function(e){
            saveVideoLocal(e.media);
        }
    });
});

function saveVideoLocal(media) {
    videoMedia = media;
}

$.videoPlay.addEventListener('click', function(e)
{
      activeMovie = Titanium.Media.createVideoPlayer({
          top : 0,
          width : '100%',
          bottom:100,
          visible:true,
          zIndex:999999,
          mediaControlStyle : Titanium.Media.VIDEO_CONTROL_DEFAULT,
          scalingMode : Titanium.Media.VIDEO_SCALING_ASPECT_FILL,
          autoplay : true,
          media: videoMedia
      });

      // Now if I use url instead of media then the video will not play. ( Same of android and iOS)
      // If I put a fake url like (url: 'http://fakeMovie.com' and still set media property the video will not play but error will not be thrown)
      // You can even put both media and url key above to same videoMedia and it will throw the error.

      // Looks like you have to set the url key at the creation of the control to not throw the error.
        // But url does not seem to be working for local media where the media key should be used.

      // Also when I get the script error the app will not crash but it will also not recognize
        //any future clicks on the listview control on the page that opened the video page.

      $.winVideo.add(activeMovie);
});


$.videoWindowClose.addEventListener('click', function(e)
{
  $.winVideo.close();
});


$.winVideo.addEventListener('close', function(e)
{
  if (activeMovie != null) {
      activeMovie.release();
      $.winVideo.remove(activeMovie);
  }
  activeMovie = null;

  $.destroy();
  $.off();
  $.winVideo = null;
});
