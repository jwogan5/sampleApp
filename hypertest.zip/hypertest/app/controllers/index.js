function doClick(e) {
	Alloy.createController('video', {}).getView().open();
}
$.index.open();


/*
var UIView = require('UIKit/UIView');
var UIColor = require('UIKit/UIColor');
var view = UIView.alloc().init();
var backgroundColor = UIColor.grayColor;
view.backgroundColor = backgroundColor;
view.addSubview(Ti.UI.createLabel({}));
$.index.add(view);
Ti.API.info(view.subviews);
*/
