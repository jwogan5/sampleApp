
$.index.open();

$.go.addEventListener('click', function(e)
{
	Alloy.createController('table', {}).getView().open();
});
