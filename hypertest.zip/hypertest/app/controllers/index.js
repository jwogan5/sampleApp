function textBlurA(e) {}
function textChangeA(e) {Ti.API.info('text changing');}
function textFocusA(e) {}
function textReturnA(e) {e.source.blur();}

// THIS CAUSES AN ERROR
$.index.windowSoftInputMode = Ti.UI.Android.SOFT_INPUT_ADJUST_PAN;

var optionIndex = 0;
$.tableViewDefault.addEventListener('click', function(e)
{
	var rowData = null;
  rowData = e.row;

  if (typeof rowData != 'undefined') {
  	switch (rowData.type) {
      case 'label':
        optionIndex = e.index;
				openOptions(rowData.name, e.row.currentValue);
  		  break;
  	}
  }
});

function openOptions(opName, opValue) {

	var newRows = [
		{font:{fontSize:16}, title: 'AAA',name:'AAA',code:'AAA',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'BBB',name:'BBB',code:'BBB',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'CCC',name:'CCC',code:'CCC',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'DDD',name:'DDD',code:'DDD',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'EEE',name:'EEE',code:'EEE',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'FFF',name:'FFF',code:'FFF',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'GGG',name:'GGG',code:'GGG',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'HHH',name:'HHH',code:'HHH',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'III',name:'III',code:'III',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'JJJ',name:'JJJ',code:'JJJ',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'LLL',name:'LLL',code:'LLL',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'MMM',name:'MMM',code:'MMM',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'NNN',name:'NNN',code:'NNN',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'OOO',name:'OOO',code:'OOO',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'PPP',name:'PPP',code:'PPP',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'QQQ',name:'QQQ',code:'QQQ',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'RRR',name:'RRR',code:'RRR',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'SSS',name:'SSS',code:'SSS',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'TTT',name:'TTT',code:'TTT',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'UUU',name:'UUU',code:'UUU',className:'stateOption',height:40, color:'#000000'},
		{font:{fontSize:16}, title: 'VVV',name:'VVV',code:'VVV',className:'stateOption',height:40, color:'#000000'},
	];

	$.tableSelections.setData(newRows);
	$.tableSelections.bottom = 0;
}

$.tableSelections.addEventListener('click', function(e)
{
	var nValue = e.row.name;
	var nCode= e.row.code;
	Ti.API.info('new value is: ' + nValue);

	Ti.API.info('Updating the label');
	var uItem = $.tableViewDefault.sections[0].rows[optionIndex];
	uItem.currentValue = nValue;
	uItem.ids = nCode;
	uItem.children[1].text = nValue;

	var uItem = $.tableViewDefault.sections[0].rows[optionIndex].children[1].text;
	Ti.API.info('Pulling the text from the updated rows label text:');
	Ti.API.info(JSON.stringify(uItem));


	$.tableSelections.bottom = -250;
});


$.index.open();
