var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
	var arg = null;
	if (obj) {
		arg = obj[key] || null;
	}
	return arg;
}

function Controller() {

	require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
	this.__controllerPath = 'table';
	this.args = arguments[0] || {};

	if (arguments[0]) {
		var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
		var $model = __processArg(arguments[0], '$model');
		var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
	}
	var $ = this;
	var exports = {};
	var __defers = {};







	$.__views.table = Ti.UI.createWindow(
	{ backgroundColor: "white", id: "table" });

	$.__views.table && $.addTopLevelView($.__views.table);
	var __alloyId2 = [];$.__views.__alloyId5 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000", text: "     Basic Information", id: "__alloyId5" });

	$.__views.__alloyId3 = Ti.UI.createTableViewSection(
	{ headerView: $.__views.__alloyId5, id: "__alloyId3" });

	__alloyId2.push($.__views.__alloyId3);$.__views.__alloyId6 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId6" });

	$.__views.__alloyId3.add($.__views.__alloyId6);$.__views.__alloyId7 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: 'Model', id: "__alloyId7" });

	$.__views.__alloyId6.add($.__views.__alloyId7);
	$.__views.__alloyId8 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter Model", id: "__alloyId8" });

	$.__views.__alloyId6.add($.__views.__alloyId8);
	$.__views.__alloyId9 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId9" });

	$.__views.__alloyId3.add($.__views.__alloyId9);$.__views.__alloyId10 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '1', id: "__alloyId10" });

	$.__views.__alloyId9.add($.__views.__alloyId10);
	$.__views.__alloyId11 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 1", id: "__alloyId11" });

	$.__views.__alloyId9.add($.__views.__alloyId11);
	$.__views.__alloyId12 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId12" });

	$.__views.__alloyId3.add($.__views.__alloyId12);$.__views.__alloyId13 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '2', id: "__alloyId13" });

	$.__views.__alloyId12.add($.__views.__alloyId13);
	$.__views.__alloyId14 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 2", id: "__alloyId14" });

	$.__views.__alloyId12.add($.__views.__alloyId14);
	$.__views.__alloyId15 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId15" });

	$.__views.__alloyId3.add($.__views.__alloyId15);$.__views.__alloyId16 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '3', id: "__alloyId16" });

	$.__views.__alloyId15.add($.__views.__alloyId16);
	$.__views.__alloyId17 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 3", id: "__alloyId17" });

	$.__views.__alloyId15.add($.__views.__alloyId17);
	$.__views.__alloyId18 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId18" });

	$.__views.__alloyId3.add($.__views.__alloyId18);$.__views.__alloyId19 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '4', id: "__alloyId19" });

	$.__views.__alloyId18.add($.__views.__alloyId19);
	$.__views.__alloyId20 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 4", id: "__alloyId20" });

	$.__views.__alloyId18.add($.__views.__alloyId20);
	$.__views.__alloyId21 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId21" });

	$.__views.__alloyId3.add($.__views.__alloyId21);$.__views.__alloyId22 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '5', id: "__alloyId22" });

	$.__views.__alloyId21.add($.__views.__alloyId22);
	$.__views.__alloyId23 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 5", id: "__alloyId23" });

	$.__views.__alloyId21.add($.__views.__alloyId23);
	$.__views.__alloyId24 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId24" });

	$.__views.__alloyId3.add($.__views.__alloyId24);$.__views.__alloyId25 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '6', id: "__alloyId25" });

	$.__views.__alloyId24.add($.__views.__alloyId25);
	$.__views.__alloyId26 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 6", id: "__alloyId26" });

	$.__views.__alloyId24.add($.__views.__alloyId26);
	$.__views.__alloyId27 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId27" });

	$.__views.__alloyId3.add($.__views.__alloyId27);$.__views.__alloyId28 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '7', id: "__alloyId28" });

	$.__views.__alloyId27.add($.__views.__alloyId28);
	$.__views.__alloyId29 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 7", id: "__alloyId29" });

	$.__views.__alloyId27.add($.__views.__alloyId29);
	$.__views.__alloyId30 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId30" });

	$.__views.__alloyId3.add($.__views.__alloyId30);$.__views.__alloyId31 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '8', id: "__alloyId31" });

	$.__views.__alloyId30.add($.__views.__alloyId31);
	$.__views.__alloyId32 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 8", id: "__alloyId32" });

	$.__views.__alloyId30.add($.__views.__alloyId32);
	$.__views.__alloyId33 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId33" });

	$.__views.__alloyId3.add($.__views.__alloyId33);$.__views.__alloyId34 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '9', id: "__alloyId34" });

	$.__views.__alloyId33.add($.__views.__alloyId34);
	$.__views.__alloyId35 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 9", id: "__alloyId35" });

	$.__views.__alloyId33.add($.__views.__alloyId35);
	$.__views.__alloyId36 = Ti.UI.createTableViewRow(
	{ height: 50, backgroundColor: "#ffffff", backgroundSelectedColor: "#ffffff", selectionStyle: Ti.UI.iOS.TableViewCellSelectionStyle.NONE, id: "__alloyId36" });

	$.__views.__alloyId3.add($.__views.__alloyId36);$.__views.__alloyId37 = Ti.UI.createLabel(
	{ width: Ti.UI.SIZE, height: Ti.UI.SIZE, color: "#000000", font: { fontSize: 14 }, left: 15, text: '10', id: "__alloyId37" });

	$.__views.__alloyId36.add($.__views.__alloyId37);
	$.__views.__alloyId38 = Ti.UI.createTextField(
	{ borderColor: "transparent", backgroundColor: "transparent", color: "#777777", height: 50, width: "65%", right: 40, autocorrect: "false", font: { fontSize: 14 }, autocapitalization: Titanium.UI.TEXT_AUTOCAPITALIZATION_NONE, returnKeyType: Titanium.UI.RETURNKEY_DONE, zIndex: 4, value: "", hintTextColor: "#b5b5b5", keyboardType: Titanium.UI.KEYBOARD_TYPE_DEFAULT, textAlign: Ti.UI.TEXT_ALIGNMENT_RIGHT, hintText: "Enter 10", id: "__alloyId38" });

	$.__views.__alloyId36.add($.__views.__alloyId38);
	$.__views.tableViewDefault = Ti.UI.createTableView(
	{ zIndex: 51, top: 151, separatorColor: "#e4e4e4", bottom: 51, data: __alloyId2, id: "tableViewDefault" });

	$.__views.table.add($.__views.tableViewDefault);
	exports.destroy = function () {};




	_.extend($, $.__views);












	_.extend($, exports);
}

module.exports = Controller;