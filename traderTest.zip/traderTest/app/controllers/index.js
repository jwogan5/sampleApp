/*
	This sample app tries to simulate the size of our production apps listViews.
	
	- Using Appc SDK 9.2.3.v20201125044640. The App is extremely fast with the sample numbers below.
		The UI is not blocked and everything seems very snappy. I am able to hit the add/fetch button
		start scrolling the listview and hit save and the listview still scrolls with everything updated
		with no UI blocking at all.
		
		Adding/Fetching Collection Items:  1st set of 50 items: Sub 1 second  |  Subsequent Loads : Sub 1 second
		Updating Items using SAVE (20 items only): Sub 1 second
		Setting Collection Items (20 items only): Sub 1 second


	- Using Appc SDK 9.3.0.GA. The App is very sluggish with the sample numbers below.
		The UI is often blocked where scrolling stops and nothing can be touched.
		The warning message is often shown: [WARN] ResourceType: Too many attribute references, stopped at: 0x01010034
		After awhile the app runs out of memory.

		Adding/Fetching Collection Items:  1st set of 50 items: 3 seconds  |  Subsequent Loads : 5 seconds
		Updating Items using SAVE (20 items only): 45 seconds
		Setting Collection Items (20 items only): 18 seconds 


	- Also listView no longer has scrollEnd event in 9.3.0.GA



	- Steps to Test: (9.3.0.GA) ( Very sluggish and Unusable )
		- Tap the Add/Fetch button. It will take 3 seconds and block UI.
		- Start scrolling the list and tap Add/Fetch. The UI freezes and it takes 5 seconds until usable again.
		- Tap Reset button at top to clear the list.
		- Tap Add/Fetch button. It will take 3 seconds and block UI.
		- Start scrolling the list and tap Save button. The UI freezes and it takes 45 seconds.
		- Tap Reset button at top to clear the list.
		- Tap the Set button at the bottom. UI Freezes and it takes 18 seconds til items show and UI is usable again.

	- Repeat the same steps above for (SDK 9.2.3.v20201125044640) ( Very fast )
		- You will see the UI barely ever stops. You can add hundreds of items with no decrease in performance.

*/



// Reset the collection for liveView
Alloy.Collections['listings'].reset();
var listingIndex = 0;
var listingsToCreateAtOnce = 10;
Alloy.Globals.moment = require('/alloy/moment');
var startTime = Alloy.Globals.moment().unix();


function doListingsFilter() {
    return Alloy.Collections['listings'].models;
}

function setStartLogTime() {
	startTime = Alloy.Globals.moment().unix();
}

function logItem(item) {
	const totalTime = Alloy.Globals.moment().unix() - startTime;
	Ti.API.info(`Logging (Total Time = ${totalTime}): ${item}`);
	setStartLogTime();
}

function doListingsTransform(model) {
    var m = model.toJSON();
    m.mainImageOverlayRight = -42;
	m.listingFlagShow = true;
	m.listingFlagColor = '#2297A9';
	m.listingFlagText = 'FEED';
	m.inventoryHideLocation = true;
    m.inventoryHideLocationHeight = Ti.UI.SIZE;
	m.tagLineTextLeft = 38;
	m.inventoryHideTagline = true;
	m.inventoryHideTaglineHeight = Ti.UI.SIZE;
	m.invHideTaglineTop = 5;
	m.inventoryHideSalePrice = true;
	m.inventoryHideSalePriceHeight = Ti.UI.SIZE;
	m.invHideSalePriceTop = 0;
	m.photoCount = 2;
	m.listingsMainImage = 'https://cdn2.commercialtrucktrader.com/v1/media/5fb3e32cc27fbf48346b0968.jpg?width=768&height=512&quality=70&bestfit=true&upsize=true&blurBackground=true&blurValue=100&upsize=true'
    return m;
}

$.Reset.addEventListener('click', e => {
	Alloy.Collections['listings'].reset();
	listingIndex = 0;
});


// Add 50 items and Fetch to show them:  ADD and FETCH against backbone tied to listview
	// Also shows to many attributes warning.
	
$.AddFetch.addEventListener('click', e => {
	setStartLogTime();
	listingsToCreateAtOnce = 50;
	$.listListings.show();

	logItem('Starting to ADD Collection Items');
	
	var y = listingIndex + listingsToCreateAtOnce;
	for(listingIndex; listingIndex < y; listingIndex++) {
		const addListing = Alloy.createModel('listings', {
			id:listingIndex,
       	 	realmId: '4',
        	adType : 'Truck',
       	 	classId: '1',
        	createDate: '3453453453',
        	dealerId: '1',
        	dealerWebsiteInventoryId: '234234242',
        	expiration: '2345254353',
        	lastUpdate: '3454353453',
        	makeId: '4435353',
        	manufacturerSerialNumber: '234234242',
        	modelId: '345345353',
        	sourceCode:'SOURCE',
        	status: 'A',
        	stockNumber: '#abc123',
        	trimId: '234234242',
        	year: '2020',
        	categories: [{id:'3454353'}],
        	price: '$50,000',
        	photos: ['1','2'],
        	featurePremium: true,
        	featureSearch: true,
        	isRequestAPrice: true,
        	tagLine: 'Hurry In',
        	tagLineIcon: 'Icon:',
			salePriceValue: '$49,000',
			listingSalePrice: '$49,000',
        	isRequestAPrice: true,
			adFeatures: '',
			makeDisplayName : 'Ford',
    		modelDisplayName : 'F150',
			trimName : 'Raptor',
			listingYMM: '2020 Ford 150',
			listingYM: '2020 Ford',
			listingMT: '150 Raptor',
			listingSCM: 'New - 500 Miles',
			watchersCount: '0',
			videoCount: '1',
			adVideoCount: '1',
			trader360Count:'1',
			expirationDay: '0',
			listStatusColor : 'red',
			listStatusText : '0 days left',
			featureCount: '0',
			likesCount:'0',
			brochureCount: '1'
		});
		Alloy.Collections.listings.add(addListing, {silent: true});
        addListing.save();
	}

	logItem('Finished Creating Collection Items using ADD backbone method');
	Alloy.Collections.listings.fetch();
	logItem('Finished Fetching Collection using FETCH backbone method');
});

$.Save.addEventListener('click', e => {
	setStartLogTime();
	logItem('Starting Save to update Collection Items');

	for(x =  0; x < 20; x++) {
		const coreListing = Alloy.Collections.listings.get(x);
        if (typeof coreListing != 'undefined') {
            coreListing.save({
				realmId: '3',
				adType : 'Cycle',
				classId: '2',
				createDate: '435353453',
				dealerId: '2',
				dealerWebsiteInventoryId: '23423345353454242',
				expiration: '7897897977',
				lastUpdate: '7897897897',
				makeId: '7897897',
				manufacturerSerialNumber: '7897897897',
				modelId: '7897897897'
			},{patch: true});
        }
	}
	logItem('Finished Updating Collection Items using SAVE backbone method');
});

$.Set.addEventListener('click', e => {
	setStartLogTime();
	logItem('Starting to add collection items using SET backbone method');
	listingsToCreateAtOnce = 20;
	$.listListings.show();
	var y = listingIndex + listingsToCreateAtOnce;
	var itemsToSet = [];
	for(listingIndex; listingIndex < y; listingIndex++) {
		itemsToSet.push({
			id:listingIndex,
       	 	realmId: '4',
        	adType : 'Truck',
       	 	classId: '1',
        	createDate: '3453453453',
        	dealerId: '1',
        	dealerWebsiteInventoryId: '234234242',
        	expiration: '2345254353',
        	lastUpdate: '3454353453',
        	makeId: '4435353',
        	manufacturerSerialNumber: '234234242',
        	modelId: '345345353',
        	sourceCode:'SOURCE',
        	status: 'A',
        	stockNumber: '#abc123',
        	trimId: '234234242',
        	year: '2020',
        	categories: [{id:'3454353'}],
        	price: '$50,000',
        	photos: ['1','2'],
        	featurePremium: true,
        	featureSearch: true,
        	isRequestAPrice: true,
        	tagLine: 'Hurry In',
        	tagLineIcon: 'Icon:',
			salePriceValue: '$49,000',
			listingSalePrice: '$49,000',
        	isRequestAPrice: true,
			adFeatures: '',
			makeDisplayName : 'Ford',
    		modelDisplayName : 'F150',
			trimName : 'Raptor',
			listingYMM: '2020 Ford 150',
			listingYM: '2020 Ford',
			listingMT: '150 Raptor',
			listingSCM: 'New - 500 Miles',
			watchersCount: '0',
			videoCount: '1',
			adVideoCount: '1',
			trader360Count:'1',
			expirationDay: '0',
			listStatusColor : 'red',
			listStatusText : '0 days left',
			featureCount: '0',
			likesCount:'0',
			brochureCount: '1'
		});
	}
	Alloy.Collections.listings.set(itemsToSet, {remove:false});
	logItem('Finished adding collection items using SET backbone method');
});


$.listListings.addEventListener('scrollend', e => {
	Ti.API.info('Scroll End Event Works ...');
});


$.testWin.open();
