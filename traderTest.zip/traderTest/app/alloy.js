Alloy.Collections['listings'] = Alloy.createCollection('listings');
Alloy.Collections['listings'].fetch();

Alloy.Collections['listings'].on('reset', function(col, opts){
    opts.previousModels.map(removeModel);
});

const removeModel = (model) => {
    model.destroy({
        wait: false
    });
}