package com.traderinteractive.fyusion;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import org.appcelerator.kroll.KrollDict;

import com.fyusion.sdk.common.FyuseSDK;
import com.fyusion.sdk.ext.carmodeflow.CarSession;
import com.fyusion.sdk.ext.carmodeflow.CarSessionActivity;

public class FyusionRecordActivity extends AppCompatActivity {

   private static final String LCAT = "AfyusionModule";
   private Integer REQCODE = 0;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        Bundle extras = i.getExtras();
        String fyuseId = extras.getString("fyuseId");
        REQCODE = extras.getInt("REQCODE");

        CarSession.init(this).withTaggingFlow(true).withShowOnWeb(false).withStaticImageFlow(true).startForResult(REQCODE);
        // withBasePath = set to main application directory where my photo uploads go so I can remove these.
        // withVIN = if a vin is set for the listing.
        // withMasterFyuseId = if fyuseId is set to a real fyuse master id.
        // Turn withShowOnWeb to false before going live.
        // View on web: https://fyu.se/api/viewer/vdp.html?uid=j5nfarmqd4w1
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.e(LCAT, "got result back from Car Session");
        super.onActivityResult(requestCode, resultCode, data);

        KrollDict dict = new KrollDict();
        dict.put("moduleHasResponse", true);
    		if (requestCode == REQCODE) {
    			dict.put("requestCode", requestCode);
    			dict.put("resultCode", resultCode);

    				if (resultCode == Activity.RESULT_OK) {
    						if (data != null) {
    								Log.e(LCAT, "Result OK with data");
    								dict.put("url", data.getStringExtra(CarSessionActivity.RESULT_EXTRA_URL));
    								dict.put("session", data.getStringExtra(CarSessionActivity.RESULT_EXTRA_SESSION_PATH));
    								dict.put("updated", data.getBooleanExtra(CarSessionActivity.RESULT_EXTRA_SESSION_UPDATED, false));
    								dict.put("tags", data.getIntExtra(CarSessionActivity.RESULT_EXTRA_TAGS, 0));
    								dict.put("images", data.getIntExtra(CarSessionActivity.RESULT_EXTRA_STATIC_IMAGES, 0));
    						} else {
    								Log.e(LCAT, "Result OK but no data");
    						}
    				} else {
    						if (resultCode == CarSessionActivity.RESULT_ERROR) {
    							dict.put("errorCode", "There was an error. Check LOG.");
    							Log.e(LCAT, "There was an error. Check LOG.");
    						} else if (resultCode == CarSessionActivity.RESULT_CAMERA_UNSUPPORTED) {
    							dict.put("errorCode", "Camera Not Supported.");
    							Log.e(LCAT, "Camera Not Supported.");
    						} else if (resultCode == CarSessionActivity.RESULT_PHONE_UNSUPPORTED) {
    							dict.put("errorCode", "Phone Not Supported.");
    							Log.e(LCAT, "Phone Not Supported.");
    						} else {
    							dict.put("sessionTags", "Result: " + resultCode);
    							Log.e(LCAT, "Result: " + resultCode);
    						}
    				}
    		}

        AfyusionModule.getFyusionModule().fireEvent("response", dict);
        setResult(resultCode);
        finish();
    }
}
