/**
 * Android Fyusion Module
 * Copyright TraderInteractive.com
 */
package com.traderinteractive.fyusion;

import org.appcelerator.kroll.KrollModule;
import org.appcelerator.kroll.annotations.Kroll;
import org.appcelerator.kroll.KrollDict;
import org.appcelerator.titanium.TiApplication;
import org.appcelerator.kroll.common.TiConfig;
import android.app.Application;
import android.app.Activity;
import android.content.Intent;
import org.appcelerator.titanium.util.TiActivitySupport;
import org.appcelerator.titanium.util.TiActivityResultHandler;
import android.util.Log;

import com.fyusion.sdk.common.FyuseSDK;

@Kroll.module(name="Afyusion", id="com.traderinteractive.fyusion")
public class AfyusionModule extends KrollModule implements TiActivityResultHandler
{
	// Standard Debugging variables
	private static final String LCAT = "AfyusionModule";
	private static final boolean DBG = TiConfig.LOGD;
	private static final String fyusionModuleVersion = "0.0.1";
	private String fyuseId;
	private Integer REQCODE;
	private static AfyusionModule module;

	public AfyusionModule()
	{
		super();
		module = this;
	}

	@Kroll.onAppCreate
	public static void onAppCreate(TiApplication app)
	{
		Log.e(LCAT, "Calling Fyuse Init in Creation of Module");
		FyuseSDK.init(app.getInstance().getApplicationContext(), "vgjN_pN5Twoz8EKVe69yOJ", "4oFb5XT3X2gr27NU7On5sILcluG3gZrf");
	}

	// Methods
	@Kroll.method
	public String getVersion()
	{
		return fyusionModuleVersion;
	}

	public static AfyusionModule getFyusionModule()
	{
		return module;
	}

	@Kroll.method
	public void startSession(KrollDict options)
	{
		fyuseId = (String) options.get("id");

		Activity activity = TiApplication.getAppRootOrCurrentActivity();
		TiActivitySupport support = (TiActivitySupport) activity;
		REQCODE = support.getUniqueResultCode();
		Intent fyusionIntent = new Intent();
		fyusionIntent.setClass(activity, FyusionRecordActivity.class);
		fyusionIntent.putExtra("fyuseId", fyuseId);
		fyusionIntent.putExtra("REQCODE", REQCODE);

		Log.e(LCAT, "Launching Fyusion Record Activity");
		support.launchActivityForResult(fyusionIntent, REQCODE, this);
	}

	@Kroll.method
	public void viewFyuseById(KrollDict options)
	{
		fyuseId = (String) options.get("id");

		Activity activity = TiApplication.getAppRootOrCurrentActivity();
		TiActivitySupport support = (TiActivitySupport) activity;
		REQCODE = support.getUniqueResultCode();
		Intent fyusionIntent = new Intent();
		fyusionIntent.setClass(activity, FyusionViewActivity.class);
		fyusionIntent.putExtra("fyuseId", fyuseId);
		fyusionIntent.putExtra("REQCODE", REQCODE);

		Log.e(LCAT, "Launching Fyusion View Activity");
		support.launchActivityForResult(fyusionIntent, REQCODE, this);
	}

	//@Override
	public void onError(Activity activity, int requestCode, Exception e)
	{
		Log.i(LCAT, "onError Called from activity result handler some how");
	}

	//@Override
	public void onResult(Activity activity, int requestCode, int resultCode, Intent data)
	{
		Log.i(LCAT, "onResult Called from activity result handler some how");
	}

}
