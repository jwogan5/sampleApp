package com.traderinteractive.fyusion;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.Nullable;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import org.appcelerator.kroll.KrollDict;
import android.support.design.widget.Snackbar;

import com.traderinteractive.fyusion.R;
import com.fyusion.sdk.common.util.UidUtil;
import com.fyusion.sdk.viewer.FyuseException;
import com.fyusion.sdk.viewer.FyuseViewer;
import com.fyusion.sdk.viewer.RequestListener;
import com.fyusion.sdk.viewer.view.RemoteFyuseView;
import android.view.View;

public class FyusionViewActivity extends AppCompatActivity {

   private static final String LCAT = "AfyusionModule";
   private RemoteFyuseView fyuseView;
   private String fyuseId;
   private View root;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        Bundle extras = i.getExtras();
        fyuseId = extras.getString("fyuseId");
        fyuseView = findViewById(R.id.remoteFyuseView);
        fyuseView.setRotateWithGravity(false);
        fyuseView.setEnforceAspectRatio(false);
        fyuseView.setVisibility(View.VISIBLE);
        FyuseViewer.with(FyusionViewActivity.this)
                .load(fyuseId)
                .listener(fyuseLoadRequestListener)
                .highRes(true)
                .into(fyuseView);
    }

    /**
     * Listener used to get informed about the loading states of a remote fyuse.
     */
    RequestListener fyuseLoadRequestListener = new RequestListener() {
        @Override
        public boolean onLoadFailed(@Nullable FyuseException e, Object o) {
            loadFailed(R.string.m_remote_load_failed);
            return false;
        }

        @Override
        public boolean onResourceReady(Object o) {
            return false;
        }

        @Override
        public void onProgress(int i) {

        }
    };

    /**
     * Inform the user about a failed loading.
     *
     * @param message message displayed in the Snackbar
     */
    private void loadFailed(int message) {
        fyuseView.setVisibility(View.INVISIBLE);
        Snackbar.make(root, message, Snackbar.LENGTH_SHORT).show();
    }
}
