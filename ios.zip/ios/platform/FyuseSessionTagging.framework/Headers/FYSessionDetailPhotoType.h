//
//  FYInteriorPhotoType.h
//  FyuseSessionTagging
//
//  Created by Jai Chaudhry on 3/29/18.
//  Copyright © 2018 Jai Chaudhry. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 Photo types used for identifying a session detail image usually captured before capturing a fyuse.
 */
typedef NS_ENUM(NSInteger, FYSessionDetailPhotoType) {
    FYSessionDetailPhotoTypeOdometer,
    FYSessionDetailPhotoTypeConsole,
    FYSessionDetailPhotoTypeVinPlate,
    FYSessionDetailPhotoTypeFrontDriverInterior,
    FYSessionDetailPhotoType2ndRowSeat,
    FYSessionDetailPhotoType3rdRowSeat,
    FYSessionDetailPhotoTypeTrunk,
    FYSessionDetailPhotoTypeEngine,
    //Start of exterior photos. Only for static flow
    FYSessionDetailPhotoTypeFrontDriverSide, // Front 3/4 drivers side
    FYSessionDetailPhotoTypeRearDriverSide, // Rear 3/4 drivers side
    FYSessionDetailPhotoTypeRearPassengerSide, // Rear 3/4 passengers side
    FYSessionDetailPhotoTypeFrontPassengerSide, //Front 3/4 passenger side
    FYSessionDetailPhotoTypeAll,
    FYSessionDetailPhotoTypeThumbnail
};

@interface FYSessionDetailPhoto: NSObject

@property (nonatomic, assign) FYSessionDetailPhotoType photoType;

@end
