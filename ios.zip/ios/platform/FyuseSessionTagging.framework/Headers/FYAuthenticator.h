
#import <Foundation/Foundation.h>

/**
 Contains permissions for the currently registered SDK user.
 */
@interface FYAuthenticator : NSObject

/**
 * Returns an authenticated request for a given plain URL.
 */
- (nullable NSURLRequest *)authenticatedRequestForURL:(nullable NSURL *)url;

/**
 * If the currently signed in SDK user has permission to upload fyuses.
 */
@property (nonatomic, readonly) BOOL haveUploadPermission;

/**
 * If the currently signed in SDK user has permission to upload fyuses.
 */
@property (nonatomic, readonly) BOOL haveUploadHighResPermission;

/**
 * If the currently signed in SDK user has permission to upload fyuses.
 */
@property (nonatomic, readonly) BOOL haveCameraPermission;

/**
 * If the currently signed in SDK user has permission to upload fyuses.
 */
@property (nonatomic, readonly) BOOL haveCameraHighResPermission;

/**
 * If the currently signed in SDK user has permission to upload fyuses.
 */
@property (nonatomic, strong, readonly, nullable) NSString *accessToken;

/**
 * KVO compliant getter to observe the current network status.
 */
@property (nonatomic, readonly) BOOL haveNetwork;

/**
 * The current app version.
 */
@property (nonatomic, strong, readonly, nullable) NSString *appVersion;

@end
