/*
 * Copyright 2013-present Fyusion, Inc.
 */

#import <Foundation/Foundation.h>

@class FYFyuse;

/**
The shared FYFyuseManager instance maintains a single diskCache instance. This cache can be configured with a byte limit, queried for its total occupied size, and uses NSDictionary style subscripting for adding and retrieving fyuses.
 */
@interface FYDiskCache : NSObject

/**
 *  @abstract The largest number of bytes that should be allowed to be taken on disk at any given time.
 *
 *  @note Entries are removed starting with the oldest at two occasions
 *
 *  1) This property is set and the cache already has more data than the new limit.
 *
 *  2) A new entry is inserted that puts the occupiedSize over the current limit.
 */
@property (nonatomic) NSUInteger cacheLimit;

/**
 *  How many bytes are currently taken up on disk by cached fyuses.
 */
@property (nonatomic, readonly) NSUInteger occupiedSize;

/**
 *  Enables NSDictionary Style Retrievals
 *
 *  ie) _diskCache[uid] = someFyuse;
 */
- (FYFyuse *)objectForKeyedSubscript:(NSString *)key;

/**
 *  Enables NSDictionary Style  Retrievals
 *  ie) someFyuse = _diskCache[uid];
 */
- (void)setObject:(FYFyuse *)obj forKeyedSubscript:(NSString *)key;

/**
 *  Use this method to completely remove all entries from the cache.
 *
 *  Caveat: Fyuses that are still being actively hosted
 *    in an FYFyuseView won't be evicted so that onscreen fyuses won't 
 *    be broken unexpectedly.
 */
- (void)clearCache;

@end
