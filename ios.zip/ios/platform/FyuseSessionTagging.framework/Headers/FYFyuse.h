
/*
 * Copyright 2013-present Fyusion, Inc.
 */

#import "FYFyuseResolution.h"
#import "FyusePriority.h"
#import "FyuseThumbnailBlocks.h"
#import "FYRotation.h"

#import <UIKit/UIKit.h>

/**
 An object representing a particular fyuse. Analagous to `UIImage` in that it is an in memory representation of a fyuse that can be assigned to an `FYFyuseView` to be viewed in a view hierarchy.
 */
@interface FYFyuse : NSObject <NSCopying>

/**
 * A blurred thumbnail of "thumb" frame of the fyuse.
 */
@property (nonatomic, readonly, nullable) UIImage *blurryImage;

/**
 * A unique identifier provided by the server to differentiate between fyuses.
 */
@property (nonatomic, readonly, nonnull) NSString *uid;

/**
 * A property denoting the rotation that has been applied to a fyuse to make it stand upright by default. In general, portrait fyuses are taller than they are wide and landscape fyuses are wider than they are tall.
 */
@property (nonatomic, readonly) FYRotation rotation;

/**
 * The local file path where the fyuse can be found. This value will only exist if the fyuse was initialized with a local file path in the first place.
 */
@property (nonatomic, readonly, nullable) NSString *filePath;

/**
 * @summary Asynchronously retrieves a thumbnail image representing the fyuse.
 *
 * @param success A success block that receives a UIImage in the event of a succesful fetch.
 *
 * @param failure A failure block that receives an NSError in the event of a failed fetch.
 */
- (void)thumbnailWithSuccess:(FYFyuseThumbnailSuccessBlock _Nullable )success failure:(FYFyuseThumbnailFailureBlock _Nullable )failure;

/**
 * @summary Returns the url from which a fyuse's thumbnail image can be downloaded.
 */
- (nullable NSURL *)thumbnailURL;

/**
 * @summary Initializer for local fyuses. This initializer will return nil unless you're using the full SDK and you use a valid local file path provided by FyuseCameraKit.
 *
 * @param filePath The local file path to find a fyuse on disk that hasn't been uploaded.
 */
- (nullable instancetype)initWithFilePath:(nonnull NSString *)filePath;
@end
