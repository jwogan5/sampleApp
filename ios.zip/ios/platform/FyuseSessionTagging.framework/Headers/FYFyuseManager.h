/*
 * Copyright 2013-present Fyusion, Inc.
 */

#import "FYDiskCache.h"
#import "FyuseThumbnailBlocks.h"

#import <CoreMotion/CoreMotion.h>

/**
 * Responsible for requesting and managing fyuse objects that need to be fetched from a server.
 */
@interface FYFyuseManager : NSObject

/**
 * The shared disk cache in charge of managing fyuses that are on disk.
 */
@property (nonatomic, readonly, nonnull) FYDiskCache *diskCache;

/**
 * The shared instance of the FYFyuseManager
 */
+ (nonnull instancetype)sharedManager;

/**
 * Request a single fyuse object given a particular UID
 */
- (void)requestFyuseWithUID:(nonnull NSString *)UID
                  onSuccess:(nullable FYFyuseRequestSuccessBlock)onSuccess
                  onFailure:(nullable FYFyuseRequestFailureBlock)onFailure;

/**
 * Request a batch of fyuse objects given an array of UIDs
 */
- (void)requestFyusesWithUIDs:(nonnull NSArray <NSString *> *)UIDs
                    onSuccess:(nullable FYFyuseBatchRequestSuccessBlock)onSuccess
                    onFailure:(nullable FYFyuseRequestFailureBlock)onFailure;


@end
