
#import <UIKit/UIKit.h>

@class FYFyuse;

/**
 * A success block for fyuse thumbnail requests that receives a single image as its argument.
 */
typedef void (^FYFyuseThumbnailSuccessBlock)(UIImage *image);

/**
 * An error block for fyuse thumbnail requests that receives an NSError object as its argument.
 */
typedef void (^FYFyuseThumbnailFailureBlock)(NSError *error);

/**
 * A success block for FYFyuse requests that receives a single fyuse object as its argument.
 */
typedef void (^FYFyuseRequestSuccessBlock)(FYFyuse *fyuse);

/**
 * A success block for FYFyuse requests that receives an array of fyuse objects as its argument.
 */
typedef void (^FYFyuseBatchRequestSuccessBlock)(NSArray <FYFyuse *> *fyuses);

/**
 * A failure block for FYFyuse requests that receives an NSError object as its argument.
 */
typedef void (^FYFyuseRequestFailureBlock)(NSError *error);
