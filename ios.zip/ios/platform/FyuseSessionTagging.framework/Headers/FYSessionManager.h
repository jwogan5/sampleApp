//
//  FYSessionManager.h
//  FyuseSessionTagging
//
//  Created by Jai Chaudhry on 3/29/18.
//  Copyright © 2018 Jai Chaudhry. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "FYSessionDetailPhotoType.h"

@class FYFyuse;

@interface FYSessionManager : NSObject

/**
 Returns the array of supported photos for a particular device.

 @return Array of FYSessionDetailPhoto objects.
 */
+ (NSArray <FYSessionDetailPhoto *> *)supportedDetailPhotos;

/**
 Returns object representing the thumbnail photo for a session
 */
+ (FYSessionDetailPhoto *)thumbnailDetailPhoto;
    
/**
 Used for requesting interior car images. To request thumbnail for the session just use `thumbnailDetailPhoto` method to get the object representing thumbnail and pass it here to get the corresponding thumbnail image.

 @param identifier Unique identifier for a particular session.
 @param photo The photo object for identifying a particular object. These would the objects returned from the method `supportedDetailPhotos`.
 @param completion The callback which will provide the requested image.
 */
+ (void)requestDetailImageForSessionId:(NSString *)identifier detailPhoto:(FYSessionDetailPhoto *)photo completion:(void(^)(UIImage *image))completion;


/**
 Used for requesting the count of tags associated with a particular session.

 @param identifier Unique identifier for a particular session.
 @return The tags count.
 */
+ (NSInteger)tagCountForSessionWithId:(NSString *)identifier;

/**
 Used for requesting a particular tag associated with a session.

 @param identifier Unique identifier for a particular session.
 @param index Index of the tag that is requested
 @param completion Callback which would return a FYFyuse object or UIImage depending on what's the type of tag. If its a fyuse, then the image would be nil and vice-versa.
 @param failure This would be called only if the requested index does not exist.
 */
+ (void)requestTagForSessionId:(NSString *)identifier withIndex:(NSInteger)index completion:(void(^)(FYFyuse *fyuse, UIImage *image))completion failure:(void(^)(void))failure;

/**
 Used for deleting a whole session.

 @param identifier Unique identifier for a particular session.
 */
+ (void)deleteSessionWithId:(NSString *)identifier;

/**
 Request the main fyuse associated with a particular session.

 @param identifier Unique identifier for a particular session.
 @param completion Completion callback which returns the main fyuse.
 */
+ (void)requestMainFyuseForSessionWithIdentifier:(NSString *)identifier completion:(void(^)(FYFyuse *fyuse))completion;

/**
 Returns a list of all session IDs saved to disk
 
 @return Array of session IDs
 */
+ (NSArray <NSString *>*)allSessionIDs;


/**
 Tells if the flow internally is 2d flow (photos only).

 @return YES if its 2d flow.
 */
+ (BOOL)is2DFlow;

@end
