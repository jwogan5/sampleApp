/*
 * Copyright 2013-present Fyusion, Inc.
 */

#import <Foundation/Foundation.h>

/**
 * The FyusePriority is used to determine how important displaying a particular fyuse is in relation to others that might be 
 * attempting to be displayed.
 */
typedef NS_ENUM(NSUInteger, FyusePriority) {
    /**
     * The fyuse is currently onscreen and should be rendered as quickly as possible.
     */
    FyusePriorityVisible,
    
    /**
     * The fyuse is offscreen but will be onscreen soon. This priority is only useful if you're using something like
     * Texture's scrollView ranges or if you've implemented your own. Otherwise you can just use Visible and Preload.
     */
    FyusePriorityDisplay,
    
    /**
     * The fyuse is offscreen and may or may not appear soon. The fyuses will yield to onscreen fyuses before being rendered.
     */
    FyusePriorityPreload,
};
