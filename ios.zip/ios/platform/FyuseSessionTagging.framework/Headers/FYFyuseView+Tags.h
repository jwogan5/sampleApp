//
//  FYFyuseView+Tags.h
//  FyuseKit
//
//  Created by Jai Chaudhry on 5/11/18.
//  Copyright © 2018 Fyusion, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FYFyuseView.h"

@interface FYFyuseView()

/**
 Set this to YES to show tags by default in the FyuseView.
 */
@property (nonatomic, assign) BOOL showTags;// Defaults to NO.

@end
