
/*
 * Copyright 2013-present Fyusion, Inc.
 */

/**
 * The FYRotation of the fyuse denotes how it has been rotated to be shown upright by default in an FYFyuseView.
 * In general, portrait fyuses will be tall and landscape fyuses will be wide.
 */
typedef NS_ENUM(NSUInteger, FYRotation) {
    /**
     * The phone was held in the landscape right orientation when the fyuse was taken and is wider than it is tall.
     */
    FYRotationLandscape = 0,

    /**
     * The phone was held in the landscape left orientation when the fyuse was taken and is wider than it is tall.
     */
    FYRotationLandscapeUpsideDown,
    
    /**
     * The phone was held in the portrait orientation when the fyuse was taken and is taller than it is wide.
     */
    FYRotationPortrait,

    /**
     * The phone was held in the portrait upside down orientation when the fyuse was taken and is taller than it is wide.
     */
    FYRotationPortraitUpsideDown,
    
    /**
     * A convenience case for getting the number of enumeration cases.
     */
    FYRotationCount
};

