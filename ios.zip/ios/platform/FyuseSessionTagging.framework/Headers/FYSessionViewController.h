//
//  FYSessionViewController.h
//  FyuseSessionTagging
//
//  Created by Jai Chaudhry on 4/3/18.
//  Copyright © 2018 Jai Chaudhry. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol FYSessionViewControllerDelegate;

/**
 This controller is used for capturing a new session or editing an exisiting session.
 */
@interface FYSessionViewController : UINavigationController

/**
 This initializer should be used when start a new session.
 */
- (instancetype)init;

/**
 This initializer should be used when opening the session for editing tags.

 @param identifier Unique id for identifying a particular session
 */
- (instancetype)initWithSessionIdentifier:(NSString *)identifier;

/**
 Implement this delegate to get the identifier for a recorded session.
 */
@property (nonatomic, weak) id<FYSessionViewControllerDelegate> sessionDelegate;

@end

@protocol FYSessionViewControllerDelegate<NSObject>

/**
 This delegate callback will only be fired once the save button is pressed. In any other circumstances you won't receive this callback.
 */
- (void)sessionController:(FYSessionViewController *)sessionController didSaveSessionWithIdentifier:(NSString *)identifier;

/**
 This delegate callback will be fired when the session controller is dismissed by tapping on cross.
 */
- (void)sessionControllerDidDismiss:(FYSessionViewController *)sessionController;

@end
