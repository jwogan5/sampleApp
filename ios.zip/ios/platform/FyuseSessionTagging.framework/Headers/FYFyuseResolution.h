/*
 * Copyright 2013-present Fyusion, Inc.
 */

#import <Foundation/Foundation.h>

/**
 * An enumeration representing the two resolutions in which fyuses can be displayed.
 */
typedef NS_ENUM(NSUInteger, FYFyuseResolution) {
    /**
     * The preview resolution is much smaller, more performant and more memory efficient than the normal resolution
     * and should be favored when showing fyuses in a scrolling feed or at a smaller size than full screen.
     */
    FYFyuseResolutionPreview,
    
    /**
     * The normal resolution is meant for fyuses that are being displayed fullscreen.
     */
    FYFyuseResolutionNormal,
};
