//
//  FYUploadSessionManager.h
//  FyuseSessionTagging
//
//  Created by Jai Chaudhry on 3/29/18.
//  Copyright © 2018 Jai Chaudhry. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FYUploadSessionManagerDelegate<NSObject>

@optional

/**
 Called when a session successfully finished uploading.

 @param uid A unique identifier for identifying the session on fyuse servers.
 */
- (void)sessionFinishedUploadingWithUID:(NSString *)uid;

/**
 Called when a session fails to upload.
 */
- (void)sessionFailedUploading;

/**
 Called when a session updated upload progress.
 
 @param progress Current state of progress as a fraction, with a range (0, 1)
 */
- (void)sessionUpdatedUploadProgress:(CGFloat)progress;

/**
 Called when a session updated preparation to upload progress.
 
 @param progress Current state of preparation to progress as a fraction, with a range (0, 1)
 */
- (void)sessionUpdatedUploadPreparationProgress:(CGFloat)progress;

@end

/**
 Central manager object for uploading session to Fyuse servers.
 NOTE: This only works for a single upload right now and should not be used for uploading sessions in parallel.
 */
@interface FYUploadSessionManager : NSObject

/**
 Uploads a session with a unique identifier

 @param identifier The unique identifier for identifying a session locally.
 */
- (void)uploadSessionWithIdentifier:(NSString *)identifier;

/**
 Cancels the already running session upload and invokes the `sessionFailedUploading` delegate callback.
 **/
- (void)cancelUpload;

/**
 Returns a uploaded unique identifier for identifying the session on fyuse servers.

 @param identifier The unique identifier for identifying a session locally.
 @return A unique identifier for identifying the session on fyuse servers.
 */
+ (NSString *)uploadedUIDForSessionIdentifier:(NSString *)identifier;

/**
 Implement this delegate to get back the uploaded session identifier.
 */
@property (nonatomic, weak) id<FYUploadSessionManagerDelegate> delegate;

/**
 Disable the upload on background. Right now we start a background task to ensure that uploads have more time to finish themselves when they the app is backgrounded. Set this flag to YES to disable this functionality.
 Defaults to NO.
 */
@property (nonatomic, assign) BOOL disableBackgroundUpload;

@end




