/*
 * Copyright 2013-present Fyusion, Inc.
 */

#import "FYFyuseResolution.h"
#import "FyusePriority.h"
#import "FYFyuse.h"

#import <UIKit/UIKit.h>

@protocol FYFyuseViewDelegate;

/**
 * FYFYuseViewError denotes the reason a fyuse failed to display.
 */
typedef NS_ENUM(NSInteger, FYFyuseViewError) {
    /**
     * The fyuse failed to display because the download failed.
     */
    FYFyuseViewErrorFailedToDownload = -3000,
    
    /**
     * The fyuse failed to display because the h264 to MJPEG conversion failed.
     */
    FYFyuseViewErrorFailedToDisplay = -3001,
};

/**
 Analagous to `UIImageView` in that it can be assigned a fyuse object through its `fyuse` property. By setting its `frame` and `contentMode` you can control how the fyuse is shown inside of a view hierarchy.
 */
@interface FYFyuseView : UIView

/**
 * @abstract The current fyuse to display in this view.
 *
 * @default nil
 * 
 */
@property (nonatomic, nullable) FYFyuse *fyuse;

/**
 * @abstract The display delegate of this fyuse view.
 *
 * @default nil
 *
 * @discussion Use this property to become the fyuseView's display delegate and be alerted to the progress of the currently displaying fyuse.
 */
@property (nonatomic, nullable, weak) id <FYFyuseViewDelegate> delegate;

/**
 * @abstract The preferred resolution at which this fyuseView should show its current fyuse.
 *
 * @default FYFyuseResolutionPreview
 *
 * @discussion The options for this property are FYFyuseResolutionPreview and FYFyuseResolutionNormal. In general, Normal resolution fyuses should be shown alone in full-screen and Preview resolution fyuses are what should be shown in a table or collection type feed.
 */
@property (nonatomic) FYFyuseResolution preferredResolution;

/**
 * @abstract Whether a fyuse should download lower resolutions while you're waiting for a higher one.
 *
 * @default NO
 *
 * @discussion If this option is set to YES (true) then Normal resolution fyuses will also 
 * download their Preview resolution represention. This can be useful when you want to show
 * something as quickly as possible since Preview fyuses download more quickly.
 *
 * In general, Preview resolution fyuses are higher priority as opposed to Normal resolution fyuses.
 */
@property (nonatomic) BOOL shouldDownloadIntermediateResolutions;

/**
 * @abstract Whether a placeholder image will show up while the fyuse is loading
 *
 * @default YES
 *
 * @discussion Set this property to NO when you'd prefer no placeholder to be shown
 */
@property (nonatomic) BOOL placeholderEnabled;

/**
 * @abstract The placeholder image will be shown in place of the fyuse itself while the fyuse is loading.
 *
 * @default nil
 *
 * @discussion By default a blurry preview will be shown but this image will be shown instead if it's been set.
 */
@property (nonatomic, nullable) UIImage *placeholderImage;

/**
 * @abstract The currently displaying resolution of the current fyuse.
 *
 * @default FYFyuseResolutionPreview
 *
 */
@property (nonatomic) FYFyuseResolution currentResolution;

/**
 * @abstract Whether a fyuse should download lower resolutions while you're waiting for a higher one.
 *
 * @default NO
 *
 * @discussion If this option is set to YES (true) then Normal resolution fyuses will also
 * download their Preview resolution represention. This can be useful when you want to show
 * something as quickly as possible since Preview fyuses download more quickly.
 *
 * In general, Preview resolution fyuses are higher priority as opposed to Normal resolution fyuses.
 */
@property (nonatomic) FyusePriority priority;

/**
 * @abstract Whether a fyuse should respond to motion events or not.
 *
 * @default YES
 *
 * @discussion This property can be useful for pausing fyuses while performing transitions or other performance sensitive actions.
 */
@property (nonatomic) BOOL motionEnabled;

/**
 * @abstract Whether zooming in is allowed with this fyuse view.
 *
 * @default NO
 *
 * @discussion Set this property to YES when you'd like users to be able to pinch to zoom into fyuses.
 */
@property (nonatomic) BOOL zoomEnabled;

/**
 * @abstract Time interval for fading away the placeholder image.
 *
 * @default 0.0
 *
 * @discussion By default, this value is 0.0 and will not fade at all. Otherwise the fyuse
 *             will fade in with an animation at the speed specified by this property.
 */
@property (nonatomic) NSTimeInterval placeholderFadeDuration;

/**
 @abstract Supply this to ensure correct behaviour for fyuseview, if its parent view controller has support certain interface orientations.
 
 @default Interface orientations supported by the App using this class.
 */
@property (nonatomic, assign) UIInterfaceOrientationMask supportedInterfaceOrientation;

/**
 * @abstract Retry after a fyuse has failed to display.
 *
 * @discussion When a fyuse has failed to display for some reason, you can call this method to have it try again.
 * 
 *  Calling this method when a fyuse has not failed does nothing.
 */
- (void)retry;
@end

/**
 Use these methods to allow a delegate object to be notified of the progress of the display of a fyuse.
 */
@protocol FYFyuseViewDelegate <NSObject>
@optional
/**
 @summary Delegate method to notify a delegate of a fyuse's display progress.
 @param fyuseView The FYFyuseView which is hosting a currently loading fyuse that has made progress.
 @param progress The current display progress normalized to a scale of 0.0 to 1.0.
 @param resolution The resolution that has made progress in displaying.
 */
- (void)fyuseView:(nonnull FYFyuseView *)fyuseView didUpdateProgress:(CGFloat)progress fyuseWithResolution:(FYFyuseResolution)resolution;

/**
 @summary Delegate method to notify a delegate that a fyuse did finish displaying.
 @param fyuseView The FYFyuseView which is hosting a currently loading fyuse that has made progress.
 @param resolution The resolution that finished displaying.
 */
- (void)fyuseView:(nonnull FYFyuseView *)fyuseView didDisplayFyuseWithResolution:(FYFyuseResolution)resolution;

/**
@summary Delegate method to notify a delegate that a fyuse failed to display.
@param fyuseView The FYFyuseView which is hosting a currently loading fyuse that has made progress.
@param error The error that caused the fyuse to fail to display.
*/
- (void)fyuseView:(nonnull FYFyuseView *)fyuseView didFailWithError:(nullable NSError *)error;

/**
 Delegate method to notify that fyuseview was single tapped.

 @param fyuseView The FYFyuseView which is hosting a currently loading fyuse.
 */
- (void)fyuseViewDidSingleTap:(nonnull FYFyuseView *)fyuseView;

/**
 Delegate method to notify the delegate of tags that have been tapped.
 
 @param fyuseView The FYFyuseView which is hosting a currently loading fyuse.
 */
- (void)fyuseView:(FYFyuseView *_Nonnull)fyuseView didTapOnTagWithIndex:(NSInteger)index;

@end
