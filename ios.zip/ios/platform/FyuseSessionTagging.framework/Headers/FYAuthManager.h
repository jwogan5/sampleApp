
#import <Foundation/Foundation.h>

@class FYAuthenticator;

/**
 * Singleton auth manager with which you can register your app with your given appID and appSecret
 */
@interface FYAuthManager : NSObject

/**
 * Initializes the SDK with your provided AppID and AppSecret.
 */
+ (nullable instancetype)initializeWithAppID:(nonnull NSString *)appID
                                   appSecret:(nonnull NSString *)appSecret;

/**
 * Auth Manager singleton for inspecting authentication details.
 */
+ (nullable instancetype)sharedManager;

/**
 * The authenticator contains app permissiosn such as upload and camera capabilities.
 */
@property (nonatomic, nullable, readonly) FYAuthenticator *auth;

/**
 * The AppID provided for your application.
 */
@property (nonatomic, strong, nonnull) NSString *appID;

/**
 * The AppSecret provided for your application.
 */
@property (nonatomic, strong, nonnull) NSString *appSecret;

@end
