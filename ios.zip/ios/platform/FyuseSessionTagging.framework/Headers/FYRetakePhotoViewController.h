//
//  FYRetakeInteriorPhotoViewController.h
//  FyuseSessionTagging
//
//  Created by Jai Chaudhry on 4/6/18.
//  Copyright © 2018 Jai Chaudhry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FYSessionDetailPhotoType.h"

@protocol FYRetakeInteriorPhotoViewControllerDelegate;

/**
 Used for retaking the session detail photos. Usually include the photo types from `FYSessionDetailPhotoType`
 */
@interface FYRetakePhotoViewController : UINavigationController

/**
 To be used for updating a particular detail photo.

 @param identifier Unique id for idenitifying a particular session
 @param photoType Image photo type
 */
- (instancetype)initWithSessionIdentifier:(NSString *)identifier photoType:(FYSessionDetailPhotoType)photoType;

/**
 Implement this delegate to be informed of the updated image. Even if you don't implement this, the photo will automatically updated in FYSessionManager.
 */
@property (nonatomic, weak) id<FYRetakeInteriorPhotoViewControllerDelegate> retakeDelegate;

@end

@protocol FYRetakeInteriorPhotoViewControllerDelegate<NSObject>

/**
 Delegate callback when a new photo is captured.

 @param controller The retake controller reference
 @param image The updated image
 */
- (void)retakeController:(FYRetakePhotoViewController *)controller didUpdatePhoto:(UIImage *)image;

@end
