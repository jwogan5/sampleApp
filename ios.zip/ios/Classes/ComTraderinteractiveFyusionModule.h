/**
 * ifyusion
 *
 * Created by Your Name
 * Copyright (c) 2018 Your Company. All rights reserved.
 */

#import "TiModule.h"

@interface ComTraderinteractiveFyusionModule : TiModule {
}

- (NSString *)appInstanceID;

//- (void)startSession:(id)arguments;


@end
