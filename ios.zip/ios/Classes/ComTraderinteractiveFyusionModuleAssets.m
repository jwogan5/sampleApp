/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "ComTraderinteractiveFyusionModuleAssets.h"

extern NSData* filterDataInRange(NSData* thedata, NSRange range);

@implementation ComTraderinteractiveFyusionModuleAssets

- (NSData *)moduleAsset
{
  

  return nil;
}

- (NSData *)resolveModuleAsset:(NSString *)path
{
  

  return nil;
}

@end
