/**
 * ifyusion
 *
 * Created by Your Name
 * Copyright (c) 2018 Your Company. All rights reserved.
 */

#import "ComTraderinteractiveFyusionModule.h"
#import "TiBase.h"
#import "TiHost.h"
#import "TiUtils.h"
#import "TiApp.h"

@import FyuseSessionTagging;

@implementation ComTraderinteractiveFyusionModule

#pragma mark Internal

// This is generated for your module, please do not change it
- (id)moduleGUID
{
  return @"6bd3cdbd-b232-42c3-b39d-2e235a9947ca";
}

// This is generated for your module, please do not change it
- (NSString *)moduleId
{
  return @"com.traderinteractive.fyusion";
}

#pragma mark Lifecycle

- (void)startup
{
  // This method is called when the module is first loaded
  // You *must* call the superclass
  [super startup];
  DebugLog(@"[DEBUG] %@ loaded", self);

  [FYAuthManager initializeWithAppID: @"vgjN_pN5Twoz8EKVe69yOJ" appSecret: @"4oFb5XT3X2gr27NU7On5sILcluG3gZrf"];
}

#pragma Public APIs

- (NSString *)example:(id)args
{
  // Example method.
  // Call with "MyModule.example(args)"
  return @"hello world";
}

- (NSString *)exampleProp
{
  // Example property getter.
  // Call with "MyModule.exampleProp" or "MyModule.getExampleProp()"
  return @"Titanium rocks!";
}

- (NSString *)appInstanceID
{
  return @"0.0.1";
}

- (void)startSession:(NSString *)sessionId
{
    if ([sessionId isEqualToString: @"newSession"]) {
      FYSessionViewController *fyuseSession = [[FYSessionViewController alloc] init];
      [[TiApp app] showModalController: fyuseSession animated: YES];
    }
    //
}

@end
