function doClick(e) {
	Alloy.createController('testmem', {parentWindow: $.index}).getView().open();
}

$.index.open();
