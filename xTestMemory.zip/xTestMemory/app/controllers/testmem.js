var args = $.args || {};

var memWin = (function() {


	/***************************************************************************************
	 * Methods for Event Listeners
	 ***************************************************************************************/
	$.winMem.addEventListener('close', function(e)
	{
		$.destroy();
		$.off();
		$.removeListener();
	});

	$.closeLabel.addEventListener('click', function(e)
	{
		$.winMem.close();
	});



}) ();
