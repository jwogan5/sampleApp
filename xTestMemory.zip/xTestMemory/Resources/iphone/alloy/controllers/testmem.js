var Alloy = require('/alloy'),
Backbone = Alloy.Backbone,
_ = Alloy._;




function __processArg(obj, key) {
	var arg = null;
	if (obj) {
		arg = obj[key] || null;
		delete obj[key];
	}
	return arg;
}

function Controller() {

	require('/alloy/controllers/' + 'BaseController').apply(this, Array.prototype.slice.call(arguments));
	this.__controllerPath = 'testmem';
	this.args = arguments[0] || {};

	if (arguments[0]) {
		var __parentSymbol = __processArg(arguments[0], '__parentSymbol');
		var $model = __processArg(arguments[0], '$model');
		var __itemTemplate = __processArg(arguments[0], '__itemTemplate');
	}
	var $ = this;
	var exports = {};
	var __defers = {};







	$.__views.winMem = Ti.UI.createWindow(
	{ id: "winMem" });

	$.__views.winMem && $.addTopLevelView($.__views.winMem);
	$.__views.windowHeader = Ti.UI.createView(
	{ id: "windowHeader" });

	$.__views.winMem.add($.__views.windowHeader);
	$.__views.closeLabel = Ti.UI.createLabel(
	{ text: 'Close the Window', id: "closeLabel" });

	$.__views.windowHeader.add($.__views.closeLabel);
	exports.destroy = function () {};




	_.extend($, $.__views);


	var args = $.args || {};

	var memWin = function () {




		$.winMem.addEventListener('close', function (e) {
			$.destroy();
			$.off();
			$.removeListener();
		});

		$.closeLabel.addEventListener('click', function (e) {
			$.winMem.close();
		});
	}();









	_.extend($, exports);
}

module.exports = Controller;